#ifndef STRING
#define STRING

void str_trim_lf (char*, int);
void str_overwrite_stdout();

#endif // STRING