#ifndef PROTO
#define PROTO

#define LENGTH_NAME 31
#define LENGTH_MSG 101
#define LENGTH_SEND 201
#define FILEHISTORY "history.txt"
#endif // PROTO