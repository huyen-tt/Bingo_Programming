# c-chatroom

> A simple chat room in C.

## Environment

- macOS, Ubuntu
- Unix Socket
- POSIX Thread Library

## Run

```
make
./server.out
./client.out
```

